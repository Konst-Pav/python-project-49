### Hexlet tests and linter status:
[![Actions Status](https://github.com/Konst-Pav/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Konst-Pav/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/0db0ca962bd1856f5413/maintainability)](https://codeclimate.com/github/Konst-Pav/python-project-49/maintainability)